package qi.com.meuprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MeuFilme3 extends AppCompatActivity {


    Button btnDrive, btnProximo, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meu_filme1);


        btnDrive = findViewById(R.id.btnDrive);
        btnProximo = findViewById(R.id.btnProximo);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

        btnProximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProximo();
            }
        });

        btnDrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirDrive();
            }
        });
    }


    public void abrirVoltar(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    public void abrirProximo(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }


    public void abrirDrive() {
        Intent janela = new Intent(Intent.ACTION_VIEW, Uri.parse("https://drive.google.com/drive/folders/1V9LvrRJiQaKimS73SUUtZ9pE0KCCguOy?usp=sharing"));
        startActivity(janela);
    }



};